## ----echo = FALSE--------------------------------------------------------
library(Binomial)

## ----eval=TRUE-----------------------------------------------------------
# we want the total number of combinations of 4 heads in 5 flips. i.e. HHHHT, THHHH, HTHHH, etc...
bin_choose(n = 5, k = 4)

# This seems easy enough to count but what if we enlarge the sample size?

bin_choose(n = 20, k = 4)

## ------------------------------------------------------------------------
# say we have the same fair coin from the example above, what is the probability that we will achieve 4 heads in 5 attempts? 

bin_probability(trials = 5, prob = .5, success = 4)

# or for larger sample sizes:

bin_probability(trials = 20, prob = .5, success = 4)

## ------------------------------------------------------------------------
# for the same coin:

bin_distribution(trials = 5, prob = .5)

## ------------------------------------------------------------------------
bin_distribution(trials = 20, prob = .5)

## ------------------------------------------------------------------------
dis1 <- bin_distribution(trials = 5, prob = .5)
plot.bindis(dis1)

## ------------------------------------------------------------------------
dis2 <- bin_distribution(trials = 20, prob = .5)
plot.bindis(dis2)

## ------------------------------------------------------------------------
bin_cumulative(trials = 5, prob = .5)


## ------------------------------------------------------------------------
bin_cumulative(trials = 20, prob = .5)

## ------------------------------------------------------------------------
cumu1 <- bin_cumulative(trials = 5, prob = .5)
cumu2 <- bin_cumulative(trials = 20, prob = .5)
plot.bincum(cumu1)
plot.bincum(cumu2)

## ------------------------------------------------------------------------
bin_variable(5, .5)

## ------------------------------------------------------------------------
binvar <- bin_variable(5,.5)
summary.binvar(binvar)

